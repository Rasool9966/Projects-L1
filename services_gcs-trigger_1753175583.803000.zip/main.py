import base64
import json
import os
import pandas as pd
from google.cloud import storage
from functions_framework import cloud_event

storage_client = storage.Client()

@cloud_event
def hello_pubsub(cloud_event):
    # Decode Pub/Sub message data
    data = base64.b64decode(cloud_event.data["message"]["data"]).decode("utf-8")
    data = json.loads(data)

    bucket_name = data["bucket"]
    file_name = data["name"]

    print(f"Processing file: gs://{bucket_name}/{file_name}")

    # Process only .csv files
    if not file_name.endswith(".csv"):
        print("Not a CSV file")
        return

    # Download the CSV file to /tmp
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(file_name)
    local_path = f"/tmp/{os.path.basename(file_name)}"
    blob.download_to_filename(local_path)
    print(f"Downloaded {file_name} to {local_path}")

    # Read CSV using pandas
    df = pd.read_csv(local_path)

    # Compute metrics
    metrics = {
        "file_name": file_name,
        "row_count": len(df),
        "null_counts": df.isnull().sum().to_dict()
    }

    # Write metrics as JSON to reports/ folder
    metrics_blob = bucket.blob(f"reports/{os.path.basename(file_name)}.json")
    metrics_blob.upload_from_string(
        data=json.dumps(metrics, indent=2),
        content_type="application/json"
    )

    print(f"Metrics written to gs://{bucket_name}/reports/{os.path.basename(file_name)}.json")
